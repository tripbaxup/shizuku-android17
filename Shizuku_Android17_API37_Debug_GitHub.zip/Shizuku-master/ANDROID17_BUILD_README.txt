SHIZUKU ANDROID 17 DEBUG BUILD

This project is configured to build a debug-signed APK on GitHub Actions.
No signing secrets or release keystore are required.

Workflow:
.github/workflows/android17-debug-build.yml

Build output artifact:
shizuku-android17-debug-apk

Important:
- Android still requires APK signatures. The Android Gradle Plugin creates/uses a debug keystore automatically.
- A debug-signed APK cannot update an official Shizuku installation because its signing certificate is different.
- If GitHub creates a fresh runner/build later, the debug certificate may differ. For permanent seamless updates, use a persistent release key instead.
