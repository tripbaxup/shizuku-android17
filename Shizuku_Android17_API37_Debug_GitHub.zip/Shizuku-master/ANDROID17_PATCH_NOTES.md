# Android 17 / API 37 compatibility patch

This tree was prepared from the supplied Shizuku source ZIP for Android 17 testing.

## Changes

1. `compileSdk` changed from 36 to 37.
2. `targetSdk` intentionally remains 36. This avoids opting into Android 17 target-37-only behavior changes while still compiling against API 37.
3. `dev.rikka.hidden` compatibility/stub dependency changed from 4.4.0 to 4.5.0. This is the key upstream compatibility update for Android 17 hidden package-manager APIs.
4. `.gitmodules` uses HTTPS instead of the SSH-only GitHub URL.
5. The source ZIP had no `.git` metadata, so version generation now falls back to `13.6.0.r1090.android17` / versionCode 1090 when built from an archive.
6. Added a GitHub Actions workflow that populates the missing `api` submodule, installs API 37, builds `:manager:assembleRelease`, and uploads the APK.

## Why this patch

Upstream Shizuku PR #2233 (July 5, 2026) changes `compileSdk` 36 -> 37 and `dev.rikka.hidden` 4.4.0 -> 4.5.0, plus updates the Shizuku-API submodule. This addresses the Android 17 failure where the service can start but installed/authorized app enumeration fails because the hidden `IPackageManager` interface changed.

## Important signing note

A locally built APK will not have the official Shizuku signing certificate. Android will therefore reject it as an in-place update over an official Shizuku APK with the same application ID. For personal testing you normally need to stop Shizuku, back up anything you need, uninstall the official manager, then install the locally signed build. Do not attempt to bypass Android signature verification.

## Build locally

Requires JDK 21, Android SDK platform 37, build-tools 36.0.0, NDK 29.0.13113456 and CMake 3.31+ as referenced by the project.

Populate the missing submodule first:

```bash
rm -rf api
git clone --depth 1 https://github.com/RikkaApps/Shizuku-API.git api
```

Then:

```bash
chmod +x gradlew
./gradlew :manager:assembleRelease
```

The included GitHub Actions workflow can do these steps on a clean hosted runner.
